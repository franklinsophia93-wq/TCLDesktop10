/* NegócioFácil 1.0: dados reais locais, duas identidades visuais, nenhuma compra fictícia. */
(() => {
  'use strict';
  const KEY='negociofacil.data.v1';
  const DEFAULT=()=>({schema:1,business:{name:'Meu negócio',segment:'Geral',owner:''},clients:[],appointments:[],items:[],sales:[],expenses:[],quotes:[],team:[],campaigns:[]});
  const tabs=['home','agenda','clients','sales','finance'];
  const labels={home:'Início',agenda:'Agenda',clients:'Clientes',sales:'Vendas',finance:'Financeiro',items:'Produtos e serviços',quotes:'Orçamentos',reports:'Relatórios',stock:'Estoque',team:'Equipe',marketing:'Marketing',whatsappPanel:'WhatsApp',support:'Suporte',tax:'Notas fiscais',more:'Mais'};
  const navIcons={home:'⌂',agenda:'▣',clients:'♟',sales:'🛒',finance:'▥',more:'•••'};
  const money=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format((Number(n)||0)/100);
  const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const day=()=>{const d=new Date(),m=new Date(d.getTime()-d.getTimezoneOffset()*60000);return m.toISOString().slice(0,10)};
  const nowLocal=()=>{const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)};
  const dateString=s=>{try{return new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}).format(new Date(s))}catch(e){return s||''}};
  const dateOnly=s=>{if(!s)return'';const[a,b,c]=s.slice(0,10).split('-');return `${c}/${b}/${a}`};
  const num=s=>Math.round(Math.max(0,Number(String(s??'').replace(',','.'))||0)*100);
  const uid=()=>`${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
  const stores={client:'clients',appointment:'appointments',item:'items',sale:'sales',expense:'expenses',quote:'quotes',member:'team',campaign:'campaigns'};
  let data=DEFAULT(),tab='home',filter='',selectedDate=day(),financePeriod='month',preview='free';
  try{const x=JSON.parse(localStorage.getItem(KEY));if(x&&x.schema===1){data={...DEFAULT(),...x};for(const k of Object.values(stores))if(!Array.isArray(data[k]))data[k]=[];}}catch(e){}
  // O plano de teste so pode ser modificado apos login nativo de ADM.
  const bridge=()=>window.AndroidBridge||null;
  const adminAvailable=()=>!!(bridge()&&typeof bridge().adminState==='function');
  let admin={configured:false,authenticated:false,username:'admin',plan:'free',testOnly:true};
  function syncAdmin(){
    if(adminAvailable()){
      try {admin=JSON.parse(bridge().adminState());}catch(e){admin={configured:false,authenticated:false,plan:'free',testOnly:true};}
    }
    preview=(admin.authenticated&&['free','pro','business'].includes(admin.plan))?admin.plan:'free';
  }
  syncAdmin();
  const isPremium=()=>preview!=='free';
  const planLabel=()=>preview==='free'?'Gratuito':preview==='pro'?'Pro':'Empresarial';
  let toastTimer;
  const notice=m=>{const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3500)};
  const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(data));return true}catch(e){notice('Não foi possível salvar. Exporte seus dados e libere espaço.');return false}};
  const findClient=id=>data.clients.find(x=>x.id===id);
  const nameClient=id=>findClient(id)?.name||'Sem cliente';
  const month=s=>(s||'').slice(0,7)===day().slice(0,7);
  const paid=x=>x.status==='paid';
  const monthlySales=()=>data.sales.filter(x=>month(x.date)&&paid(x)).reduce((a,x)=>a+(x.amount||0),0);
  const monthlyExpenses=()=>data.expenses.filter(x=>month(x.date)).reduce((a,x)=>a+(x.amount||0),0);
  const todaySales=()=>data.sales.filter(x=>x.date===day()&&paid(x)).reduce((a,x)=>a+(x.amount||0),0);
  const monthlyAppts=()=>data.appointments.filter(x=>month(x.datetime)).length;
  const upcoming=()=>data.appointments.filter(x=>x.datetime>=nowLocal().slice(0,16)&&x.status!=='cancelled').sort((a,b)=>a.datetime.localeCompare(b.datetime)).slice(0,5);
  function header(){return `<header class="topbar"><div class="brand"><span class="brand-icon">${isPremium()?'♛':'▣'}</span><div><div class="brand-label">NegócioFácil</div><div class="brand-sub">${h(data.business.name)}</div></div></div><div class="top-actions">${admin.authenticated?'<span class="viewtag">ADM • TESTE</span>':''}<button class="circle-icon" data-action="plans" aria-label="Conhecer planos">${isPremium()?'♛':'♧'}</button><button class="circle-icon" data-action="more" aria-label="Menu">☰</button></div></header>`}
  function nav(){return `<nav class="bottom-nav" aria-label="Navegação principal">${[...tabs.slice(0,4),'more'].map(k=>`<button class="nav-button ${(tab===k||((tab==='items'||tab==='quotes'||tab==='finance'||tab==='reports'||tab==='stock'||tab==='team'||tab==='marketing'||tab==='whatsappPanel'||tab==='support')&&k==='more'))?'active':''}" data-action="goto" data-tab="${k}"><span class="nav-ico">${navIcons[k]||'▥'}</span>${labels[k]}</button>`).join('')}</nav>`}
  function ad(){return preview==='free'?`<div class="ad-card" aria-label="Área publicitária reservada">▤ &nbsp; Área reservada para publicidade<br>AdMob ainda não ativado</div>`:''}
  function promote(){return `<div class="upgrade-card"><div><strong>♛ &nbsp; Seu negócio pode crescer</strong><p>Conheça o Pro: relatórios avançados, sem anúncios e muito mais.</p></div><button class="btn small" data-action="plans">Ver Pro ›</button></div>`}
  function appointmentsList(entries){return entries.length?`<div class="list">${entries.map(x=>`<div class="list-row"><div class="avatar" style="background:#e6f4ff;color:#0d7bd5">◷</div><div class="list-main"><b>${h(x.title)}</b><small>${h(nameClient(x.clientId))} · ${h(dateString(x.datetime))}</small></div><button class="circle-icon" style="width:32px;height:32px;box-shadow:none" data-action="edit" data-kind="appointment" data-id="${h(x.id)}" aria-label="Editar compromisso">›</button></div>`).join('')}</div>`:`<div class="empty"><span class="symbol">▣</span>Nenhum compromisso registrado.<br>Adicione o primeiro usando o botão +.</div>`}
  function lightHome(){return `<section class="welcome"><h1>Olá${data.business.owner?', '+h(data.business.owner):''}! 👋</h1><p>Vamos organizar seu negócio hoje?</p></section><div class="quickgrid">
    ${tile('▣','Agenda','blue','agenda')}${tile('♟','Clientes','green','clients')}${tile('▣','Serviços','orange','items')}${tile('🛒','Vendas','pink','sales')}${tile('▥','Financeiro','purple','finance')}${tile('•••','Mais','gray','more')}
  </div><div class="section-head"><h2>Próximos compromissos</h2><button class="linklike" data-action="goto" data-tab="agenda">Ver todos ›</button></div>${appointmentsList(upcoming())}${promote()}${ad()}`}
  function tile(icon,label,color,target){return `<button class="quicktile ${color}" data-action="goto" data-tab="${target}"><span class="tileicon">${icon}</span><b>${label}</b></button>`}
  function premiumHome(){const now=new Date();return `<section class="welcome"><h1>Olá${data.business.owner?', '+h(data.business.owner):''}! 👋</h1><p>Seu negócio em um só lugar.</p></section><div class="datepill">◷ &nbsp; ${h(now.toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'}))}</div><div class="premium-stats">
    <div class="premium-box"><small>↗ Vendas hoje</small><strong>${money(todaySales())}</strong></div><div class="premium-box"><small>♧ Clientes cadastrados</small><strong>${data.clients.length}</strong></div><div class="premium-box"><small>▥ Receita do mês</small><strong>${money(monthlySales())}</strong></div><div class="premium-box"><small>↘ Despesas do mês</small><strong>${money(monthlyExpenses())}</strong></div>
  </div><div class="section-head"><h2>Ferramentas profissionais</h2><span class="subtle">Recursos em teste</span></div><div class="action-grid">
    ${actionTile('▣','Agenda','blue','agenda')}${actionTile('♟','Clientes','green','clients')}${actionTile('🛒','Vendas','pink','sales')}${actionTile('▤','Orçamentos','purple','quotes')}${actionTile('▣','Serviços','orange','items')}${actionTile('▥','Produtos','orange','items')}
    ${actionTile('▥','Financeiro','purple','finance')}${actionTile('▂','Relatórios','teal','reports')}${actionTile('♟','Equipe','teal','team',preview!=='business')}${actionTile('▣','Estoque','pink','stock')}${actionTile('➤','Marketing','purple','marketing')}${actionTile('☏','WhatsApp','green','whatsappPanel')}${actionTile('▤','Notas fiscais','blue','tax',true)}${actionTile('⚙','Configurações','blue','settings')}${actionTile('ⓘ','Suporte','pink','support')}
  </div><div class="section-head"><h2>Próximos compromissos</h2><button class="linklike" data-action="goto" data-tab="agenda">Ver todos ›</button></div>${appointmentsList(upcoming())}<div class="premium-banner"><b>♛ &nbsp; Pro e Empresarial</b><p>Acesso administrativo de teste. Relatórios, estoque e campanhas locais disponíveis; notas fiscais e permissões remotas ainda não estão ativos. Nenhuma cobrança ocorre.</p><button class="btn small secondary" data-action="admin" style="margin-top:8px">Painel ADM</button></div>`}
  function actionTile(icon,label,color,target,locked=false){return `<button class="action-tile ${color} ${locked?'locked':''}" data-action="${locked?'premium':'goto'}" data-tab="${target}"><span class="tileicon">${icon}</span>${label}</button>`}
  function heading(title,subtitle,kind){return `<div class="page-top"><div><h1>${title}</h1><p>${subtitle}</p></div>${kind?`<button class="btn" data-action="add" data-kind="${kind}">+ Novo</button>`:''}</div>`}
  function listRows(type,rows){if(!rows.length)return `<div class="empty"><span class="symbol">☰</span>Nenhum registro encontrado.<br>Toque em “+ Novo” para começar.</div>`;
    return `<div class="list">${rows.map(x=>{
      let line='',label='',suffix='';
      if(type==='client'){label=x.name;line=`${x.phone||'Sem telefone'}${x.notes?' · '+x.notes:''}`;suffix='♟'}
      if(type==='appointment'){label=x.title;line=`${nameClient(x.clientId)} · ${dateString(x.datetime)}`;suffix='▣'}
      if(type==='item'){label=x.name;line=`${x.type==='product'?'Produto · '+(Number(x.stockQty)||0)+' unidades':'Serviço'} · ${money(x.price)}`;suffix='▤'}
      if(type==='member'){label=x.name;line=`${x.role||'Colaborador'} · ${x.phone||'Sem contato'} (cadastro local)`;suffix='♟'}
      if(type==='campaign'){label=x.title;line=`${x.message||''}`;suffix='➤'}
      if(type==='sale'){label=x.description;line=`${nameClient(x.clientId)} · ${dateOnly(x.date)} · ${x.status==='paid'?'Recebida':'Pendente'}`;suffix=money(x.amount)}
      if(type==='expense'){label=x.description;line=dateOnly(x.date);suffix=money(x.amount)}
      if(type==='quote'){label=x.description;line=`${nameClient(x.clientId)} · ${dateOnly(x.date)}`;suffix=money(x.amount)}
      return `<div class="list-row"><div class="avatar">${type==='client'?h((x.name||'?').slice(0,1).toUpperCase()):type==='expense'?'↘':type==='sale'?'↗':h(suffix==='▣'?'▣':'▤')}</div><div class="list-main"><b>${h(label)}</b><small>${h(line)}</small></div>${(type==='campaign')?`<button class="btn small secondary" data-action="sharecampaign" data-id="${h(x.id)}">Compartilhar</button>`:''}${(type==='client'&&x.phone)?`<button class="circle-icon" style="width:33px;height:33px;box-shadow:none" data-action="whatsapp" data-id="${h(x.id)}" aria-label="Conversar pelo WhatsApp">☏</button>`:''}${type==='sale'||type==='expense'||type==='quote'?`<span class="list-end">${h(suffix)}</span>`:''}<button class="circle-icon" style="width:33px;height:33px;box-shadow:none" data-action="edit" data-kind="${type}" data-id="${h(x.id)}" aria-label="Editar">›</button></div>`;
    }).join('')}</div>`}
  function clients(){return `${heading('Clientes','Cadastre e encontre seus clientes.','client')}<input class="searchbox" type="search" name="search" aria-label="Buscar clientes" placeholder="⌕  Buscar cliente..." value="${h(filter)}">${listRows('client',data.clients.filter(x=>`${x.name} ${x.phone}`.toLowerCase().includes(filter.toLowerCase())).sort((a,b)=>a.name.localeCompare(b.name)))}`}
  function agenda(){const base=new Date(`${selectedDate}T12:00:00`);let days=[];for(let i=-3;i<=3;i++){const d=new Date(base);d.setDate(base.getDate()+i);const local=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);days.push(`<button data-action="date" data-value="${local}" class="${local===selectedDate?'selected':''}">${d.toLocaleDateString('pt-BR',{weekday:'short'})}<strong>${d.getDate()}</strong></button>`)}return `${heading('Agenda','Organize compromissos e atendimentos.','appointment')}<div class="schedule-day">${days.join('')}</div>${appointmentsList(data.appointments.filter(x=>x.datetime.slice(0,10)===selectedDate).sort((a,b)=>a.datetime.localeCompare(b.datetime)))}<div class="section-head"><h2>Próximos atendimentos</h2></div>${appointmentsList(upcoming())}`}
  function sales(){const total=data.sales.reduce((n,x)=>n+(paid(x)?x.amount:0),0);return `${heading('Vendas','Registre vendas, pedidos e recebimentos.','sale')}<div class="card stat-card"><span class="stat-caption">Recebido no mês</span><span class="big">${money(monthlySales())}</span><small class="stat-caption">${data.sales.filter(x=>month(x.date)).length} vendas registradas neste mês</small></div><div class="section-head"><h2>Histórico de vendas</h2><button class="linklike" data-action="goto" data-tab="quotes">Orçamentos ›</button></div>${listRows('sale',[...data.sales].sort((a,b)=>b.date.localeCompare(a.date)))}`}
  function finance(){const revenues=monthlySales(),expenses=monthlyExpenses();return `${heading('Financeiro','Acompanhe o dinheiro que entra e sai.')}<div class="card stat-card"><span class="stat-caption">Resultado do mês</span><span class="big" style="color:${revenues-expenses>=0?'var(--positive)':'var(--negative)'}">${money(revenues-expenses)}</span><small class="stat-caption">Vendas recebidas menos despesas registradas</small></div><div class="two-stats"><div class="card stat-card"><span class="stat-caption">↗ Recebido</span><span class="big">${money(revenues)}</span></div><div class="card stat-card"><span class="stat-caption">↘ Despesas</span><span class="big">${money(expenses)}</span></div></div><div class="mini-actions"><button class="btn" data-action="add" data-kind="expense">+ Despesa</button><button class="btn secondary" data-action="add" data-kind="sale">+ Venda</button><button class="btn outline" data-action="premium" data-tab="reports">Relatórios Pro ♛</button></div><div class="section-head"><h2>Despesas</h2></div>${listRows('expense',[...data.expenses].sort((a,b)=>b.date.localeCompare(a.date)))}`}
  function items(){return `${heading('Produtos e serviços','Um catálogo para qualquer ramo de negócio.','item')}${listRows('item',[...data.items].sort((a,b)=>a.name.localeCompare(b.name)))}`}
  function quotes(){return `${heading('Orçamentos','Crie e compartilhe orçamentos simples.','quote')}${listRows('quote',[...data.quotes].sort((a,b)=>b.date.localeCompare(a.date)))}<p class="tagline">Compartilhamento de texto disponível ao editar. PDF com logotipo será exclusivo do Pro.</p>`}
  /** Relatorio calculado unicamente sobre cadastros reais: nenhuma receita simulada. */
  function reports(){
    const now=new Date();let periods=[];
    for(let i=5;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);const key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
      const sales=data.sales.filter(x=>x.date?.startsWith(key)&&x.status==='paid').reduce((a,x)=>a+(x.amount||0),0);
      const expenses=data.expenses.filter(x=>x.date?.startsWith(key)).reduce((a,x)=>a+(x.amount||0),0);
      periods.push({key,label:d.toLocaleDateString('pt-BR',{month:'short'}),sales,expenses});}
    const max=Math.max(1,...periods.flatMap(x=>[x.sales,x.expenses]));
    const rows=periods.map(x=>`<div class="nf-report-row"><span>${h(x.label)}</span><div class="nf-bar-track"><div class="nf-bar-revenue" style="width:${Math.round(x.sales/max*100)}%"></div><div class="nf-bar-expense" style="width:${Math.round(x.expenses/max*100)}%"></div></div><b>${money(x.sales-x.expenses)}</b></div>`).join('');
    const top=data.clients.map(c=>({name:c.name,total:data.sales.filter(x=>x.clientId===c.id&&x.status==='paid').reduce((a,x)=>a+(x.amount||0),0)})).filter(x=>x.total>0).sort((a,b)=>b.total-a.total).slice(0,5);
    return `${heading('Relatórios','Análise do movimento dos últimos seis meses.')}<div class="card stat-card"><span class="stat-caption">Saldo registrado no mês</span><span class="big">${money(monthlySales()-monthlyExpenses())}</span><small>Calculado apenas pelas vendas recebidas e despesas lançadas.</small></div><div class="card"><b>Receitas e despesas mensais</b><p class="tagline">Azul: receitas recebidas · Vermelho: despesas</p>${rows}</div><div class="card"><b>Clientes com mais compras</b>${top.length?`<div class="list">${top.map(x=>`<div class="row-between" style="padding:12px 0"><span>${h(x.name)}</span><strong>${money(x.total)}</strong></div>`).join('')}</div>`:'<p class="tagline">Ainda não há vendas recebidas associadas a clientes.</p>'}</div><div class="card"><b>Atendimentos do mês: ${monthlyAppts()}</b><p class="tagline">São contados também os atendimentos cancelados, pois foram registrados na agenda.</p></div>`;
  }
  function stock(){const products=data.items.filter(x=>x.type==='product');const low=products.filter(x=>(Number(x.stockQty)||0)<=(Number(x.minQty)||0));return `${heading('Estoque','Controle manual das quantidades cadastradas.')}<div class="two-stats"><div class="card stat-card"><span class="stat-caption">Produtos cadastrados</span><span class="big">${products.length}</span></div><div class="card stat-card"><span class="stat-caption">Abaixo do mínimo</span><span class="big">${low.length}</span></div></div>${products.length?`<div class="list">${products.map(x=>`<div class="list-row"><div class="list-main"><b>${h(x.name)}</b><small>${Number(x.stockQty)||0} em estoque · mínimo ${Number(x.minQty)||0}</small></div><button class="btn small secondary" data-action="edit" data-kind="item" data-id="${h(x.id)}">Ajustar</button></div>`).join('')}</div>`:'<div class="empty">Cadastre um produto em Produtos e serviços para controlar o estoque.</div>'}<div class="warning">Nesta versão, as quantidades são atualizadas manualmente. Registrar uma venda ainda não reduz o estoque automaticamente.</div>`}
  function team(){return `${heading('Equipe','Cadastre colaboradores do negócio.','member')}${listRows('member',data.team)}<div class="warning">O cadastro da equipe é local. Contas separadas, login de funcionários, sincronização e permissões de acesso ainda precisam de um servidor e não estão ativos.</div>`}
  function marketing(){return `${heading('Marketing','Prepare campanhas para compartilhar manualmente.','campaign')}${listRows('campaign',data.campaigns)}<div class="warning">Não enviamos mensagens em massa automaticamente. O envio depende da sua ação e das regras e consentimentos de contato do WhatsApp.</div>`}
  function whatsappPanel(){const rows=data.clients.filter(x=>x.phone&&x.phone.replace(/\D/g,'').length>=10);return `${heading('WhatsApp','Abra conversas individuais com seus clientes.')}${rows.length?`<div class="list">${rows.map(x=>`<div class="list-row"><div class="list-main"><b>${h(x.name)}</b><small>${h(x.phone)}</small></div><button class="btn small secondary" data-action="whatsapp" data-id="${h(x.id)}">Conversar</button></div>`).join('')}</div>`:'<div class="empty">Cadastre clientes com telefone para iniciar conversas.</div>'}<div class="warning">As conversas são abertas pelo WhatsApp. Não existe automação de mensagens nesta versão.</div>`}
  function support(){return `${heading('Ajuda e suporte','Respostas rápidas para o uso do NegócioFácil.')}<div class="stack"><div class="card"><b>Onde ficam meus dados?</b><p class="tagline">Nesta etapa, somente no seu celular. Faça backup em Mais → Configurações regularmente.</p></div><div class="card"><b>Como funciona a troca de plano?</b><p class="tagline">No APK de testes, entre no painel ADM. Não representa uma assinatura de verdade.</p></div><div class="card"><b>Como registrar uma venda?</b><p class="tagline">Abra Vendas, toque + Novo e informe o valor, data e pagamento.</p></div><div class="card"><b>O aplicativo emite notas fiscais?</b><p class="tagline">Ainda não. É necessária integração fiscal homologada, credenciais e regras tributárias.</p></div></div>`}
  function shareCampaign(id){const x=data.campaigns.find(c=>c.id===id);if(!x)return;const msg=x.title+'\n\n'+x.message;
    if(navigator.share)navigator.share({title:x.title,text:msg}).catch(()=>{});
    else modal('Compartilhar campanha','Copie a mensagem abaixo e envie apenas para quem autorizou o contato.',`<textarea readonly style="width:100%;min-height:150px">${h(msg)}</textarea><div class="modal-footer"><button class="btn" data-action="close">Fechar</button></div>`);
  }
  function adminCard(){return `<div class="card"><div class="row-between"><div><b>🔒 Administração</b><p class="tagline">${admin.authenticated?'Autenticado como admin · '+planLabel()+' (TESTE)':admin.configured?'Acesso reservado à conta admin.':'Configure a senha do proprietário deste dispositivo.'}</p></div><button class="btn secondary small" data-action="admin">${admin.authenticated?'Painel ADM':admin.configured?'Entrar':'Criar ADM'}</button></div></div>`}
  function more(){return `${heading('Mais ferramentas','Gerencie e personalize o seu negócio.')}<div class="grid-menu">
  ${tile('▤','Produtos e serviços','gray','items')}${tile('▤','Orçamentos','gray','quotes')}${tile('⚙','Configurações','gray','settings')}${tile('♛','Conhecer planos','purple','plans')}
  </div><div class="section-head"><h2>Seu plano</h2></div><div class="card"><b>Plano ${admin.authenticated?planLabel()+' (teste do administrador)':'gratuito'} ativo</b><p class="tagline">Clientes, agenda, catálogo, vendas e financeiro básico. Dados salvos neste dispositivo.</p><button class="btn" data-action="plans">Conhecer Pro e Empresarial</button></div>${adminCard()}${ad()}`}
  function settings(){return `${heading('Configurações','Personalização e segurança dos dados.')}<div class="stack"><div class="card"><div class="row-between"><div><b>Meu negócio</b><p class="tagline">${h(data.business.name)} · ${h(data.business.segment)}</p></div><button class="btn secondary small" data-action="business">Editar</button></div></div><div class="card"><b>Dados e cópias de segurança</b><p class="tagline">Os dados ficam apenas neste dispositivo nesta etapa. Faça exportações regularmente para evitar perdas.</p><div class="mini-actions"><button class="btn secondary" data-action="export">↓ Exportar dados</button><button class="btn outline" data-action="import">↑ Importar backup</button></div><input type="file" id="file-import" accept="application/json,.json" hidden></div><div class="card"><b>Assinatura</b><p class="tagline">${admin.authenticated?'Prévia ADM: '+planLabel()+'. Não existe assinatura paga ativa.':'Gratuito · Pro e Empresarial aguardam integração segura de cobrança.'}</p><button class="btn small" data-action="plans">Ver planos</button></div>${adminCard()}<div class="card"><b>Sobre</b><p class="tagline">NegócioFácil · compilação de teste local. Não possui anúncios ativos, pagamentos, login de usuários em nuvem nem sincronização. Acesso ADM é exclusivo para testes neste dispositivo.</p></div></div>`}
  function render(){document.body.className=isPremium()?'theme-premium':'theme-free';const page=tab==='home'?(isPremium()?premiumHome():lightHome()):tab==='clients'?clients():tab==='agenda'?agenda():tab==='sales'?sales():tab==='finance'?finance():tab==='items'?items():tab==='quotes'?quotes():tab==='reports'&&isPremium()?reports():tab==='stock'&&isPremium()?stock():tab==='marketing'&&isPremium()?marketing():tab==='team'&&preview==='business'?team():tab==='whatsappPanel'&&isPremium()?whatsappPanel():tab==='support'&&isPremium()?support():tab==='settings'?settings():more();const root=document.getElementById('app');root.innerHTML=header()+`<main class="page">${page}</main>`+nav();const meta=document.querySelector('meta[name=theme-color]');meta?.setAttribute('content',isPremium()?'#081a33':'#f5f9ff');document.title=`${labels[tab]||'Início'} • NegócioFácil`;}
  const modalRoot=()=>document.getElementById('modal-root');
  function modal(title,description,body,footer=''){modalRoot().innerHTML=`<div class="modal-bg" role="presentation"><section class="modal" role="dialog" aria-modal="true" aria-label="${h(title)}"><div class="modal-header"><h2>${h(title)}</h2><button class="close" data-action="close" aria-label="Fechar">×</button></div>${description?`<p class="description">${h(description)}</p>`:''}${body}${footer}</section></div>`;const el=modalRoot().querySelector('input:not([type=hidden]),select,textarea,button');setTimeout(()=>el?.focus(),20)}
  const close=()=>{modalRoot().innerHTML=''};
  const field=(label,name,type='text',value='',required=true)=>`<div class="field"><label for="field-${name}">${h(label)}</label><input id="field-${name}" name="${name}" type="${type}" value="${h(value)}" ${required?'required':''} ${type==='number'?'min="0" step="0.01" inputmode="decimal"':''}></div>`;
  const choices=(label,name,opts,value='')=>`<div class="field"><label for="field-${name}">${h(label)}</label><select id="field-${name}" name="${name}">${opts.map(([id,label])=>`<option value="${h(id)}" ${String(value)===String(id)?'selected':''}>${h(label)}</option>`).join('')}</select></div>`;
  const clientsOptions=()=>[['','Sem cliente'],...data.clients.map(x=>[x.id,x.name])];
  const numberValue=n=>(n/100).toFixed(2);
  function recordModal(kind,id){const key=stores[kind];if(!key)return;const record=data[key].find(x=>x.id===id)||{};const editing=!!record.id;let body='';
    switch(kind){
      case 'client':body=field('Nome do cliente','name','text',record.name)+field('Telefone com DDD (opcional)','phone','tel',record.phone||'',false)+`<div class="field"><label for="field-notes">Observações (opcional)</label><textarea id="field-notes" name="notes">${h(record.notes||'')}</textarea></div>`;break;
      case 'appointment':body=field('Serviço ou compromisso','title','text',record.title)+choices('Cliente','clientId',clientsOptions(),record.clientId||'')+field('Dia e horário','datetime','datetime-local',record.datetime||nowLocal())+choices('Situação','status',[['scheduled','Agendado'],['completed','Concluído'],['cancelled','Cancelado']],record.status||'scheduled');break;
      case 'item':body=field('Nome','name','text',record.name)+choices('Tipo','type',[['service','Serviço'],['product','Produto']],record.type||'service')+field('Preço (R$)','price','number',numberValue(record.price||0))+(isPremium()?field('Estoque atual (somente produtos)','stockQty','number',record.stockQty??0)+field('Avisar quando chegar a','minQty','number',record.minQty??0):'');break;
      case 'sale':body=field('Descrição da venda','description','text',record.description)+choices('Cliente','clientId',clientsOptions(),record.clientId||'')+field('Valor (R$)','amount','number',numberValue(record.amount||0))+field('Data','date','date',record.date||day())+choices('Pagamento','status',[['paid','Recebido'],['pending','Pendente']],record.status||'paid');break;
      case 'expense':body=field('Descrição da despesa','description','text',record.description)+field('Valor (R$)','amount','number',numberValue(record.amount||0))+field('Data','date','date',record.date||day());break;
      case 'quote':body=field('Descrição do orçamento','description','text',record.description)+choices('Cliente','clientId',clientsOptions(),record.clientId||'')+field('Valor (R$)','amount','number',numberValue(record.amount||0))+field('Data','date','date',record.date||day());break;
      case 'member':body=field('Nome','name','text',record.name)+field('Função (ex.: vendedor)','role','text',record.role||'',false)+field('Contato','phone','tel',record.phone||'',false);break;
      case 'campaign':body=field('Nome da campanha','title','text',record.title)+`<div class="field"><label>Mensagem</label><textarea name="message" required>${h(record.message||'')}</textarea></div>`;break;
    }
    const title={client:'cliente',appointment:'compromisso',item:'produto ou serviço',sale:'venda',expense:'despesa',quote:'orçamento',member:'membro da equipe',campaign:'campanha'}[kind];
    modal((editing?'Editar ':'Novo ')+title,'Os registros são salvos neste dispositivo.',`<form id="record-form" data-kind="${kind}" data-id="${h(id||'')}">${body}<div class="modal-footer">${editing?`<button class="btn danger" type="button" data-action="delete" data-kind="${kind}" data-id="${h(id)}">Excluir</button>`:''}<button class="btn secondary" type="button" data-action="close">Cancelar</button><button class="btn" type="submit">Salvar</button></div></form>${editing&&kind==='quote'?`<button class="btn secondary" style="width:100%;margin-top:10px" data-action="sharequote" data-id="${h(id)}">Compartilhar orçamento por texto</button>`:''}`);
  }
  function businessModal(){modal('Dados do negócio','Essas informações aparecem no topo do aplicativo.',`<form id="business-form">${field('Nome do negócio','name','text',data.business.name)}${field('Seu nome (opcional)','owner','text',data.business.owner||'',false)}${choices('Tipo de atividade','segment',[['Geral','Outro / Geral'],['Serviços','Prestação de serviços'],['Comércio','Comércio'],['Ambos','Produtos e serviços']],data.business.segment)}<div class="modal-footer"><button class="btn secondary" type="button" data-action="close">Cancelar</button><button class="btn" type="submit">Salvar</button></div></form>`)}
  function plans(){modal('Escolha seu plano','Uma única aplicação. O visual e as ferramentas mudam quando uma assinatura válida for confirmada.',`<div class="plans"><div class="plan"><b>♛ &nbsp;Pro</b><strong>R$ 29,90<small style="font-size:10px">/mês</small></strong><p>Sem anúncios, relatórios avançados, financeiro completo, orçamentos em PDF, estoque, marketing e integrações.</p></div><div class="plan"><b>♛ &nbsp;Empresarial</b><strong>R$ 59,90<small style="font-size:10px">/mês</small></strong><p>Tudo do Pro, com equipe, permissões e mais usuários para o negócio.</p></div></div><div class="warning" style="margin-top:13px"><b>Assinaturas ainda indisponíveis.</b> Os pagamentos só serão habilitados após integrar e validar Google Play Billing com verificação de compra no servidor. Nenhuma cobrança ocorre nesta prévia.</div><div class="modal-footer"><button class="btn secondary" data-action="admin">Acesso de administrador</button><button class="btn" data-action="close">Entendi</button></div>`)}
  function premiumFeature(name){
    const teamRestricted=name==='team'&&preview==='pro';
    const title=teamRestricted?'Equipe Empresarial':name==='tax'?'Emissão fiscal oficial':'Recurso em desenvolvimento';
    const message=teamRestricted?'Cadastros de equipe com acesso compartilhado e permissões dependem do plano Empresarial e de autenticação em servidor.':name==='tax'?'O NegócioFácil ainda não emite notas fiscais legalmente válidas. A integração exige regras e credenciais fiscais.':'Este recurso ainda depende de integração e testes.';
    modal(title,message,`<div class="modal-footer"><button class="btn secondary" data-action="close">Voltar</button><button class="btn" data-action="plans">Conhecer planos</button></div>`);
  }
  function adminModal(){
    if(!adminAvailable())return modal('Administração','O acesso protegido do administrador está disponível somente no aplicativo Android instalado.',`<div class="warning">No navegador esta função não está ativada.</div><div class="modal-footer"><button class="btn" data-action="close">Entendi</button></div>`);
    if(admin.authenticated){
      return modal('Painel do administrador','Conta: admin · Alterações restritas a este dispositivo · Apenas TESTE',
        `<div class="card"><b>Escolha o plano para testar na mesma conta</b><p class="tagline">O visual e os dados permanecem no único aplicativo. Estes planos não representam pagamentos reais.</p><div class="mini-actions"><button class="btn ${preview==='free'?'':'outline'}" data-action="admin-plan" data-value="free">Gratuito</button><button class="btn ${preview==='pro'?'':'outline'}" data-action="admin-plan" data-value="pro">Pro</button><button class="btn ${preview==='business'?'':'outline'}" data-action="admin-plan" data-value="business">Empresarial</button></div></div><div class="warning">🔒 Ambiente de testes: funções avançadas ainda em implementação. A permissão ADM não libera serviços pagos reais.</div><div class="modal-footer"><button class="btn danger" data-action="admin-logout">Sair do ADM</button><button class="btn" data-action="close">Fechar</button></div>`);
    }
    return modal(admin.configured?'Login de administrador':'Criar conta de administrador',
      admin.configured?'Entre para alternar os três planos no mesmo aplicativo.':'A conta admin é criada neste celular e protegida por uma senha de pelo menos 8 caracteres. Não é uma conta em nuvem.',
      `<form id="admin-form"><div class="field"><label>Usuário</label><input type="text" name="username" value="admin" required autocomplete="username"></div><div class="field"><label>Senha</label><input type="password" name="password" required minlength="8" autocomplete="${admin.configured?'current-password':'new-password'}"></div>${admin.configured?'':'<div class="field"><label>Confirme a senha</label><input type="password" name="confirm" required minlength="8" autocomplete="new-password"></div>'}<div class="modal-footer"><button class="btn secondary" type="button" data-action="close">Cancelar</button><button class="btn" type="submit">${admin.configured?'Entrar':'Criar ADM'}</button></div></form>`);
  }
  function adminResult(raw){try{return JSON.parse(raw)}catch(e){return{ok:false,message:'Erro de comunicação com o administrador.'}}}
  function adminSubmit(e){
    e.preventDefault();
    if(!adminAvailable())return notice('Acesso ADM somente no aplicativo instalado.');
    const form=e.target;
    const username=form.querySelector('[name=username]').value;
    const password=form.querySelector('[name=password]').value;
    if(!admin.configured&&password!==form.querySelector('[name=confirm]').value)return notice('As senhas precisam ser iguais.');
    const result=adminResult(admin.configured?bridge().loginAdmin(username,password):bridge().createAdmin(username,password));
    form.querySelectorAll('input[type=password]').forEach(input=>input.value='');
    if(!result.ok)return notice(result.message);
    syncAdmin();close();render();adminModal();notice(result.message);
  }
  function adminPlan(plan){
    if(!adminAvailable()||!admin.authenticated)return notice('Faça login como administrador.');
    const result=adminResult(bridge().setAdminTestPlan(plan));
    if(!result.ok)return notice(result.message);
    syncAdmin();tab='home';close();render();notice('Plano '+planLabel()+' aplicado à conta admin (TESTE).');
  }
  function adminLogout(){
    if(adminAvailable())bridge().logoutAdmin();
    syncAdmin();tab='home';close();render();notice('Você saiu do administrador. Plano gratuito em exibição.');
  }
  function exportData(){const content=JSON.stringify({...data,exportedAt:new Date().toISOString()},null,2);if(window.AndroidBridge&&typeof window.AndroidBridge.exportBackup==='function'){window.AndroidBridge.exportBackup(content);notice('Escolha onde salvar seu backup JSON.');return}const file=new Blob([content],{type:'application/json'});const url=URL.createObjectURL(file);const a=document.createElement('a');a.href=url;a.download=`NegocioFacil-backup-${day()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);notice('Backup gerado. Guarde o arquivo em um lugar seguro.')}
  function importData(file){if(!file)return;if(file.size>5_000_000){notice('Arquivo muito grande. Máximo de 5 MB.');return}file.text().then(text=>{const obj=JSON.parse(text);const types=Object.values(stores);if(obj.schema!==1||!obj.business||typeof obj.business.name!=='string'||types.some(k=>!Array.isArray(obj[k])||obj[k].length>50000||obj[k].some(x=>!x||typeof x!=='object'||typeof x.id!=='string')))throw Error('Formato de backup inválido');if(!confirm('Importar este backup substituirá os dados atuais deste dispositivo. Deseja continuar?'))return;data={...DEFAULT(),...obj};if(save()){close();tab='home';render();notice('Backup importado com sucesso.')}}).catch(e=>notice('Não foi possível importar: '+e.message))}
  function shareQuote(id){const x=data.quotes.find(x=>x.id===id);if(!x)return;const msg=`ORÇAMENTO - ${data.business.name}\nCliente: ${nameClient(x.clientId)}\nServiço/produto: ${x.description}\nValor: ${money(x.amount)}\nData: ${dateOnly(x.date)}`;if(navigator.share)navigator.share({title:'Orçamento',text:msg}).catch(()=>{});else if(navigator.clipboard?.writeText)navigator.clipboard.writeText(msg).then(()=>notice('Orçamento copiado para compartilhar.')).catch(()=>notice('Falha ao copiar.'));else modal('Orçamento','Copie o texto:',`<textarea style="width:100%;min-height:170px">${h(msg)}</textarea>`)}
  function clickAction(e){const a=e.target.closest('[data-action]');if(!a)return;const action=a.dataset.action,id=a.dataset.id,kind=a.dataset.kind;
    if(action==='close')return close();
    if(action==='goto'){tab=a.dataset.tab;if(tab==='plans')return plans();filter='';render();return}
    if(action==='more'){tab='more';filter='';render();return}
    if(action==='plans')return plans();
    if(action==='admin')return adminModal();
    if(action==='admin-plan')return adminPlan(a.dataset.value);
    if(action==='admin-logout')return adminLogout();

    if(action==='premium')return premiumFeature(a.dataset.tab||'Funcionalidade avançada');
    if(action==='business')return businessModal();
    if(action==='add'||action==='edit')return recordModal(kind,id);
    if(action==='export')return exportData();
    if(action==='import')return document.getElementById('file-import')?.click();
    if(action==='sharequote')return shareQuote(id);
    if(action==='sharecampaign')return shareCampaign(id);
    if(action==='whatsapp'){const c=findClient(id);const tel=(c?.phone||'').replace(/\D/g,'');if(tel){const phone=tel.startsWith('55')?tel:'55'+tel;(window.AndroidBridge&&typeof window.AndroidBridge.openExternal==='function'?window.AndroidBridge.openExternal(`https://wa.me/${phone}`):window.open(`https://wa.me/${phone}`,'_blank','noopener,noreferrer'))}else notice('Cadastre um telefone válido antes.');return}
    if(action==='date'){selectedDate=a.dataset.value;render();return}
    if(action==='delete'){if(!confirm('Excluir este registro? Esta ação não pode ser desfeita.'))return;const k=stores[kind];if(k){data[k]=data[k].filter(x=>x.id!==id);save();close();render();notice('Registro excluído.')}return}
  }
  function formSubmit(e){const form=e.target;if(form.id==='admin-form')return adminSubmit(e);if(!['record-form','business-form'].includes(form.id))return;e.preventDefault();const raw=Object.fromEntries(new FormData(form));if(form.id==='business-form'){data.business={name:(raw.name||'').trim(),owner:(raw.owner||'').trim(),segment:raw.segment};if(!data.business.name)return notice('Informe o nome do negócio.');save();close();render();notice('Negócio atualizado.');return}
    const kind=form.dataset.kind,k=stores[kind],id=form.dataset.id;let item={...raw,id:id||uid()};const existing=data[k].find(x=>x.id===id);if(existing)item={...existing,...item};for(const value of ['name','title','description'])if(value in item){item[value]=item[value].trim();if(!item[value])return notice('Preencha a descrição ou o nome.');}
    if(['sale','expense','quote'].includes(kind)){item.amount=num(raw.amount);if(item.amount<=0)return notice('Informe um valor maior que zero.');}
    if(kind==='item'){item.price=num(raw.price); if(isPremium()){item.stockQty=Math.floor(Math.max(0,Number(raw.stockQty)||0));item.minQty=Math.floor(Math.max(0,Number(raw.minQty)||0));}}
    if(kind==='appointment'&&!item.datetime)return notice('Informe data e horário.');
    if(kind==='campaign'&&!(item.message||'').trim())return notice('Escreva uma mensagem para a campanha.');
    if(existing)data[k]=data[k].map(x=>x.id===id?item:x);else data[k].push(item);
    if(save()){close();render();notice(existing?'Registro atualizado!':'Registro cadastrado!')}
  }
  document.addEventListener('click',clickAction);
  document.addEventListener('submit',formSubmit);
  document.addEventListener('input',e=>{if(e.target.name==='search'){const v=e.target.value;filter=v;const start=e.target.selectionStart;render();const input=document.querySelector('input[name=search]');input?.focus();try{input?.setSelectionRange(start,start)}catch(error){}}});
  document.addEventListener('change',e=>{if(e.target.id==='file-import')importData(e.target.files?.[0])});
  document.addEventListener('click',e=>{if(e.target.classList.contains('modal-bg'))close()});
  if(!window.AndroidBridge&&'serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
  render();
  window.NegocioFacilBack=()=>{if(modalRoot().firstElementChild){close();return true}if(tab!=='home'){tab='home';filter='';render();return true}return false};
  window.NegocioFacilTest={getData:()=>JSON.parse(JSON.stringify(data)),getAdmin:()=>JSON.parse(JSON.stringify(admin)),syncAdmin,adminPlan,selectTab:t=>{tab=t;render()},save,monthSales:monthlySales};
})();
