# NegócioFácil 0.2 — Uma aplicação Android, três modalidades

## Estado do projeto

- Uma única aplicação Android (`br.com.negociofacil.app`) e o mesmo banco local do primeiro APK.
- Grátis: aparência clara, clientes, agenda, serviços/produtos, vendas, despesas, orçamentos, backups.
- Pro (teste ADM): aparência escura, relatórios calculados pelos dados cadastrados, estoque manual, campanhas manuais, WhatsApp individual e ajuda.
- Empresarial (teste ADM): o mesmo plano Pro e cadastro local de membros da equipe.
- O login `admin` de TESTE permite alternar os planos no **mesmo dispositivo** sem compras reais.
- Recursos **não lançados**: credenciais de funcionários, permissões entre múltiplos usuários, sincronização em servidor, emissão fiscal homologada, cobrança real, assinaturas Google Play, anúncios AdMob, automação oficial WhatsApp, integração bancária.
- O cadastro de equipe não libera acesso remoto nem permite login separado.
- As campanhas dependem de ação do usuário para compartilhamento. Não há envio em massa.
- Estoque é atualizado manualmente, ainda não automaticamente pelas vendas.

## Versão e instalação

Pacote: `br.com.negociofacil.app`

Versão do código atual: `versionCode 2`, `versionName 0.2.0-profissionais-teste`.

Atualizar uma instalação Android exige o MESMO identificador de pacote, um código de versão compatível e o MESMO certificado de assinatura (ou prova de rotação). O APK 0.1 foi assinado para debug num processo anterior; não há confirmação de que a chave privada antiga está preservada. Portanto, a instalação do APK 0.2 sobre o 0.1 **pode falhar** por assinatura diferente. Faça **Mais → Configurações → Exportar dados** no APK antigo. Se desinstalar, apagará os dados locais; importe o backup na versão nova.

Para futuras atualizações sem reinstalar, configure permanentemente uma chave de assinatura privada no cofre de segredos do CI, com estas quatro variáveis:

- `NF_KEYSTORE_FILE` (caminho para .jks montado no executor)
- `NF_KEYSTORE_PASSWORD`
- `NF_KEY_ALIAS`
- `NF_KEY_PASSWORD`

Não commitar ou publicar a chave privada em repositório público. O Android Gradle usa a chave estável quando todas as variáveis estão disponíveis; caso contrário, `assembleDebug` assina com a chave de desenvolvimento do executor, que pode mudar a cada execução.

## Dados e segurança

Os dados ainda estão em armazenamento local da WebView (`localStorage`). São persistentes entre encerramentos e entre atualizações compatíveis, mas NÃO sobrevivem à desinstalação. Exportar dados e guardar o JSON são cuidados essenciais. Há login administrador local protegido por senha; isso NÃO substitui um backend que verifique direitos comerciais pagos.

## Testes

Use `python3 tests/test_app.py` com Chromium e Playwright instalados. Os testes verificam o mesmo app, 3 planos via ADM, CRUD de clientes/agenda/itens/vendas/despesas/orçamentos, relatórios com histórico, controle de estoque, campanhas, suporte, cadastro de equipe e backup. Não substituem testes no aparelho Android.

## Próximas etapas

1. Assinatura estável e teste de atualização com backup/recuperação.
2. Sistema de autenticação e permissões real com sincronização e proteção dos dados.
3. Google Play Billing com verificação server-side, AdMob com políticas de consentimento.
4. Integração fiscal regulamentada quando houver credenciais e provedores definidos; emissão de nota fiscal não é apenas gerar um PDF.
5. Automação de WhatsApp somente pela integração oficial e conforme consentimento.
