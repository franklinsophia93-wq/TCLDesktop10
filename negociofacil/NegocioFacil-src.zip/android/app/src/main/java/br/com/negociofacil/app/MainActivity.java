package br.com.negociofacil.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Um unico aplicativo, com vistas Free e Pro/Empresarial no mesmo WebView.
 *  Nesta etapa nao ha vendas, cobranca, AdMob ou verificacao de assinatura.
 */
public final class MainActivity extends Activity {
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private static final String HOME = APP_ORIGIN + "/assets/www/index.html";
    private static final int REQUEST_OPEN_JSON = 1001;
    private static final int REQUEST_SAVE_JSON = 1002;
    private WebView webView;
    private ValueCallback<Uri[]> pendingFileChooser;
    private byte[] pendingBackup;
    private WebViewAssetLoader assetLoader;
    private long lastBackPress;
    private static final String ADMIN_STORAGE = "negociofacil.local-admin.test.v1";
    private static final int HASH_ROUNDS = 150000;
    private boolean administratorSignedIn = false;
    private final Object adminLock = new Object();

    private SharedPreferences adminPreferences() {
        return getSharedPreferences(ADMIN_STORAGE, MODE_PRIVATE);
    }

    /** O estado e o acesso do administrador existem apenas neste dispositivo de TESTE.
     *  Nunca usar esta chave local como prova de uma assinatura paga na producao.
     */
    private JSONObject adminStatus() {
        SharedPreferences prefs = adminPreferences();
        JSONObject state = new JSONObject();
        try {
            state.put("configured", prefs.contains("passwordHash"));
            state.put("authenticated", administratorSignedIn);
            state.put("username", "admin");
            state.put("plan", administratorSignedIn ? prefs.getString("testPlan", "free") : "free");
            state.put("testOnly", true);
        } catch (org.json.JSONException impossible) { /* Literais estaticos */ }
        return state;
    }

    private static byte[] derivePassword(String value, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(value.toCharArray(), salt, HASH_ROUNDS, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); }
    }

    private static String reply(boolean ok, String message) {
        JSONObject result = new JSONObject();
        try { result.put("ok", ok); result.put("message", message); }
        catch (org.json.JSONException ignored) {}
        return result.toString();
    }


    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(244,248,255));
        getWindow().setNavigationBarColor(Color.rgb(244,248,255));

        assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,248,255));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new LocalActions(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) {
                    return assetLoader.shouldInterceptRequest(uri);
                }
                // Nao renderizar conteudo remoto neste WebView com ponte JavaScript.
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                    java.util.Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                String url = target.toString();
                if (url.startsWith(APP_ORIGIN + "/assets/www/")) return false;
                openExternalUrl(url);
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = callback;
                Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                open.addCategory(Intent.CATEGORY_OPENABLE);
                open.setType("application/json");
                try {
                    startActivityForResult(open, REQUEST_OPEN_JSON);
                } catch (ActivityNotFoundException e) {
                    pendingFileChooser = null;
                    callback.onReceiveValue(null);
                    show("Não há seletor de arquivos disponível.");
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl(HOME);
    }

    private void show(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private void openExternalUrl(String value) {
        if (!value.startsWith("https://")) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value)));
        } catch (ActivityNotFoundException e) { show("Nenhum navegador disponível."); }
    }

    private final class LocalActions {
        @JavascriptInterface public String adminState() {
            synchronized (adminLock) { return adminStatus().toString(); }
        }

        @JavascriptInterface public String createAdmin(String user, String password) {
            synchronized (adminLock) {
                if (adminPreferences().contains("passwordHash"))
                    return reply(false, "O acesso administrador ja foi configurado.");
                if (!"admin".equalsIgnoreCase(user == null ? "" : user.trim()))
                    return reply(false, "O usuario de administracao deve ser admin.");
                if (password == null || password.length() < 8 || password.length() > 128)
                    return reply(false, "Crie uma senha entre 8 e 128 caracteres.");
                try {
                    byte[] salt = new byte[16];
                    new SecureRandom().nextBytes(salt);
                    byte[] hashed = derivePassword(password, salt);
                    boolean done = adminPreferences().edit()
                        .putString("passwordSalt", Base64.getEncoder().encodeToString(salt))
                        .putString("passwordHash", Base64.getEncoder().encodeToString(hashed))
                        .putString("testPlan", "free").commit();
                    if (!done) return reply(false, "Nao foi possivel salvar a conta.");
                    administratorSignedIn = true;
                    return reply(true, "Conta administradora criada. Selecione seu plano de teste.");
                } catch (Exception e) { return reply(false, "Erro ao proteger a senha de administrador."); }
            }
        }

        @JavascriptInterface public String loginAdmin(String user, String password) {
            synchronized (adminLock) {
                SharedPreferences prefs = adminPreferences();
                if (!prefs.contains("passwordHash")) return reply(false, "Configure o administrador primeiro.");
                long now = System.currentTimeMillis();
                if (now < prefs.getLong("blockedUntil", 0))
                    return reply(false, "Muitas tentativas. Tente novamente em um minuto.");
                boolean ok = false;
                try {
                    byte[] salt = Base64.getDecoder().decode(prefs.getString("passwordSalt", ""));
                    byte[] expected = Base64.getDecoder().decode(prefs.getString("passwordHash", ""));
                    byte[] entered = derivePassword(password == null ? "" : password, salt);
                    ok = "admin".equalsIgnoreCase(user == null ? "" : user.trim())
                         && MessageDigest.isEqual(expected, entered);
                } catch (Exception ignored) { ok = false; }
                if (ok) {
                    prefs.edit().remove("failedAttempts").remove("blockedUntil").apply();
                    administratorSignedIn = true;
                    return reply(true, "Login de administrador realizado.");
                }
                int attempts = prefs.getInt("failedAttempts", 0) + 1;
                SharedPreferences.Editor edit = prefs.edit();
                if (attempts >= 5) {
                    edit.putInt("failedAttempts", 0).putLong("blockedUntil", now + 60000L);
                } else edit.putInt("failedAttempts", attempts);
                edit.apply();
                return reply(false, "Usuario ou senha incorretos.");
            }
        }

        @JavascriptInterface public String setAdminTestPlan(String plan) {
            synchronized (adminLock) {
                if (!administratorSignedIn) return reply(false, "Entre como administrador primeiro.");
                if (!("free".equals(plan) || "pro".equals(plan) || "business".equals(plan)))
                    return reply(false, "Plano desconhecido.");
                boolean saved = adminPreferences().edit().putString("testPlan", plan).commit();
                return reply(saved, saved ? "Plano de TESTE alterado." : "Falha ao salvar o plano.");
            }
        }

        @JavascriptInterface public String logoutAdmin() {
            synchronized (adminLock) {
                administratorSignedIn = false;
                return reply(true, "Acesso de administrador encerrado.");
            }
        }

        @JavascriptInterface public void openExternal(String value) {
            // Permitir somente contatos oficiais do WhatsApp.
            if (value != null && value.matches("https://wa\\.me/[0-9]{10,16}")) {
                runOnUiThread(() -> openExternalUrl(value));
            }
        }

        @JavascriptInterface public void exportBackup(String json) {
            if (json == null || json.length() > 10000000) {
                show("Backup inválido ou muito grande.");
                return;
            }
            runOnUiThread(() -> {
                pendingBackup = json.getBytes(StandardCharsets.UTF_8);
                String date = new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(new Date());
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("application/json");
                save.putExtra(Intent.EXTRA_TITLE, "NegocioFacil-backup-" + date + ".json");
                try {
                    startActivityForResult(save, REQUEST_SAVE_JSON);
                } catch (ActivityNotFoundException e) {
                    pendingBackup = null;
                    show("Não há gerenciador de arquivos disponível.");
                }
            });
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request, result, intent);
        if (request == REQUEST_OPEN_JSON) {
            if (pendingFileChooser != null) {
                Uri uri = result == RESULT_OK && intent != null ? intent.getData() : null;
                pendingFileChooser.onReceiveValue(uri != null ? new Uri[]{uri} : null);
                pendingFileChooser = null;
            }
        } else if (request == REQUEST_SAVE_JSON) {
            if (pendingBackup == null) return;
            if (result == RESULT_OK && intent != null && intent.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(intent.getData())) {
                    if (out == null) throw new IOException("Saída indisponível");
                    out.write(pendingBackup);
                    show("Backup salvo com sucesso.");
                } catch (IOException e) { show("Não foi possível salvar o backup."); }
            }
            pendingBackup = null;
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("window.NegocioFacilBack ? window.NegocioFacilBack() : false", value -> {
            if ("true".equals(value)) return;
            long now = System.currentTimeMillis();
            if (now - lastBackPress <= 1900) finish();
            else { lastBackPress = now; show("Toque novamente para sair."); }
        });
    }

    @Override protected void onDestroy() {
        if (pendingFileChooser != null) {
            pendingFileChooser.onReceiveValue(null);
            pendingFileChooser = null;
        }
        administratorSignedIn = false;
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }
}
