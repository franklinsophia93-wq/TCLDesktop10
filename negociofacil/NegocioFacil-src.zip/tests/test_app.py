#!/usr/bin/env python3
"""Testes automatizados da interface única do NegócioFácil.
Requer Chromium e playwright; NÃO substitui a compilação/uso real no Android.
"""
from pathlib import Path
import json
import re
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT/'web'
HTML=(WEB/'index.html').read_text(encoding='utf-8').replace('<link rel="stylesheet" href="style.css">','').replace('<script src="app.js" defer></script>','')
HTML=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '', HTML)  # Testes injetam JS local; producao mantem CSP.
STYLES=(WEB/'style.css').read_text(encoding='utf-8')
CODE=(WEB/'app.js').read_text(encoding='utf-8')

with sync_playwright() as p:
    b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
    page.set_default_timeout(4500)
    errors=[]
    page.on('pageerror', lambda exc:errors.append(str(exc)))
    page.set_content(HTML)
    page.evaluate('''() => {
      const db = {};
      const store = {getItem: k => Object.hasOwn(db,k) ? db[k] : null, setItem: (k,v) => { db[k]=String(v); }, removeItem: k => { delete db[k]; }};
      Object.defineProperty(window, 'localStorage', {configurable: true, value: store});
      Object.defineProperty(window, 'sessionStorage', {configurable: true, value: store});
    }''')
    # Ponte Android simulada SOMENTE em testes automatizados do navegador.
    # No APK, autorização real de troca de plano é implementada em Java.
    page.evaluate('''() => {
      const adm={configured:false,authenticated:false,username:'admin',plan:'free',testOnly:true};
      const state=()=>JSON.stringify({...adm,plan:adm.authenticated?adm.plan:'free'});
      const ret=(ok,message)=>JSON.stringify({ok,message});
      window.AndroidBridge={
        adminState:state,
        createAdmin:(username,pass)=>{ if(adm.configured||username!=='admin'||pass.length<8)return ret(false,'Dados invalidos');adm.configured=true;adm.authenticated=true;adm.plan='free';adm.secret=pass;return ret(true,'ADM criado'); },
        loginAdmin:(username,pass)=>{if(username!==adm.username||pass!==adm.secret)return ret(false,'Senha invalida');adm.authenticated=true;return ret(true,'ADM autenticado');},
        logoutAdmin:()=>{adm.authenticated=false;return ret(true,'Sessao encerrada');},
        setAdminTestPlan:plan=>{if(!adm.authenticated||!['free','pro','business'].includes(plan))return ret(false,'Acesso nao autorizado');adm.plan=plan;return ret(true,'Plano aplicado');},
        exportBackup:s=>{window.backupTest=JSON.parse(s)}
      };
    }''')
    page.add_style_tag(content=STYLES)
    page.add_script_tag(content=CODE)

    assert page.title().endswith('NegócioFácil')
    assert page.locator('body').get_attribute('class') == 'theme-free'
    assert 'AdMob ainda não ativado' in page.locator('#app').inner_text()

    def goto(tab):
        el=page.locator(f'button[data-action=goto][data-tab={tab}]')
        if el.count(): el.first.click()
        else: page.evaluate('(x)=>window.NegocioFacilTest.selectTab(x)', tab)
    def open_form(kind):
        page.locator(f'button[data-action=add][data-kind={kind}]').first.click()
    def submit(**kwargs):
        for key,value in kwargs.items():
            el=page.locator(f'form#record-form [name={key}]')
            if el.evaluate('(el)=>el.tagName')=='SELECT':el.select_option(str(value))
            else:el.fill(str(value))
        page.locator('form#record-form button[type=submit]').click()
    def data():return page.evaluate('window.NegocioFacilTest.getData()')

    goto('clients'); open_form('client');submit(name='Maria Silva',phone='21999990000')
    assert len(data()['clients'])==1
    client_id=data()['clients'][0]['id']

    goto('more');goto('items');open_form('item');submit(name='Corte de cabelo',type='service',price='35.50')
    assert data()['items'][0]['price']==3550

    goto('agenda');open_form('appointment');submit(title='Corte marcado',clientId=client_id,datetime='2026-11-10T14:30')
    assert data()['appointments'][0]['title']=='Corte marcado'

    goto('sales');open_form('sale');submit(description='Serviço realizado',clientId=client_id,amount='100.25',date='2026-10-27',status='paid')
    assert data()['sales'][0]['amount']==10025

    goto('more');goto('finance');open_form('expense');submit(description='Material',amount='23.40',date='2026-10-27')
    assert data()['expenses'][0]['amount']==2340

    goto('more');goto('quotes');open_form('quote');submit(description='Visita técnica',clientId=client_id,amount='200.00')
    assert len(data()['quotes'])==1

    # Registros editáveis; exclusão somente após confirmação.
    goto('clients');page.locator('button[data-kind=client][data-action=edit]').first.click()
    page.locator('form#record-form [name=name]').fill('Maria Oliveira')
    page.locator('form#record-form button[type=submit]').click()
    assert data()['clients'][0]['name']=='Maria Oliveira'

    goto('home')
    assert 'Ver Pro' in page.locator('#app').inner_text()
    ROOT.joinpath('previews').mkdir(exist_ok=True)
    page.wait_for_timeout(3700)  # esconde avisos temporarios antes da captura
    page.screenshot(path=str(ROOT/'previews/NegocioFacil-gratuito.png'), full_page=True)

    # Sem login de ADM, nenhum usuario gratuito deve migrar de plano.
    page.evaluate("window.NegocioFacilTest.adminPlan('pro')")
    assert page.locator('body').get_attribute('class')=='theme-free'

    # Criar login administrador no proprio aparelho (simulado pela ponte).
    goto('more')
    page.locator('[data-action=admin]').first.click()
    assert page.locator('#admin-form').count()==1
    page.locator('#admin-form [name=username]').fill('admin')
    page.locator('#admin-form [name=password]').fill('minha-senha-de-teste')
    page.locator('#admin-form [name=confirm]').fill('minha-senha-de-teste')
    page.locator('#admin-form button[type=submit]').click()
    assert page.locator('button[data-action=admin-plan]').count()==3
    assert page.evaluate('window.NegocioFacilTest.getAdmin().authenticated') is True

    page.locator('button[data-action=admin-plan][data-value=pro]').click()
    assert page.locator('body').get_attribute('class')=='theme-premium'
    assert 'Relatórios' in page.locator('#app').inner_text()
    assert 'AdMob ainda não ativado' not in page.locator('#app').inner_text()
    assert len(data()['clients'])==1  # Mesmo app, mesmos dados
    page.wait_for_timeout(450)
    page.screenshot(path=str(ROOT/'previews/NegocioFacil-pro.png'), full_page=True)
    assert 'ADM • TESTE' in page.locator('#app').text_content()
    page.locator('button[data-tab=reports]').click()
    assert 'Relatórios' in page.locator('main').inner_text()
    assert 'Receitas e despesas mensais' in page.locator('main').inner_text()
    assert page.locator('.nf-report-row').count()==6
    goto('stock')
    assert 'Estoque' in page.locator('main').inner_text()
    goto('items')
    page.locator('button[data-action=add][data-kind=item]').first.click()
    submit(name='Camisa de algodão', type='product', price='90', stockQty='12', minQty='5')
    assert data()['items'][-1]['stockQty']==12
    goto('stock')
    assert '12 em estoque' in page.locator('main').inner_text()
    goto('marketing')
    open_form('campaign')
    submit(title='Promoção de outubro', message='Olá! Temos novidades para você.')
    assert data()['campaigns'][0]['title']=='Promoção de outubro'
    page.locator('button[data-action=sharecampaign]').first.click()
    assert page.locator('.modal textarea').count()==1
    page.locator('[data-action=close]').first.click()
    goto('whatsappPanel')
    assert 'Maria Oliveira' in page.locator('main').inner_text()
    goto('support')
    assert 'Onde ficam meus dados?' in page.locator('main').inner_text()
    goto('home')

    # ADM pode alternar para empresarial na mesma conta sem perder os cadastros.
    page.locator('[data-action=admin]').first.click()
    page.locator('button[data-action=admin-plan][data-value=business]').click()
    assert page.evaluate('window.NegocioFacilTest.getAdmin().plan')=='business'
    assert len(data()['clients'])==1
    goto('team')
    open_form('member')
    submit(name='Pedro Souza',role='Atendente',phone='21999999999')
    assert data()['team'][0]['name']=='Pedro Souza'
    assert 'permissões de acesso ainda precisam de um servidor' in page.locator('main').inner_text()
    goto('home')

    # Logout impede a aparencia paga, mesmo se o plano ADM ficou empresarial.
    page.locator('[data-action=admin]').first.click()
    page.locator('[data-action=admin-logout]').click()
    assert page.locator('body').get_attribute('class')=='theme-free'
    assert 'AdMob ainda não ativado' in page.locator('#app').inner_text()
    goto('more')
    page.locator('[data-action=admin]').first.click()
    page.locator('#admin-form [name=username]').fill('admin')
    page.locator('#admin-form [name=password]').fill('senha-errada')
    page.locator('#admin-form button[type=submit]').click()
    assert page.evaluate('window.NegocioFacilTest.getAdmin().authenticated') is False
    page.locator('#admin-form [name=password]').fill('minha-senha-de-teste')
    page.locator('#admin-form button[type=submit]').click()
    assert page.evaluate('window.NegocioFacilTest.getAdmin().authenticated') is True
    assert page.locator('body').get_attribute('class')=='theme-premium'

    # Backup via canal Android nativo (sem permissões invasivas).
    page.locator('[data-action=close]').first.click()
    page.evaluate('window.backupTest=null')
    goto('more');goto('settings');page.locator('[data-action=export]').click()
    assert page.evaluate('window.backupTest.clients[0].name')=='Maria Oliveira'

    # Testa navegação e entradas de texto hostis como texto, nao como HTML.
    page.evaluate("window.NegocioFacilTest.adminPlan('free')")
    goto('clients');open_form('client');submit(name='<script>alert(1)</script>',phone='21988880000')
    assert page.locator('.list script').count()==0  # O navegador nao interpreta o cadastro como script.
    assert '<script>alert(1)</script>' in page.locator('.list').inner_text()
    assert not errors, errors
    assert page.evaluate("window.localStorage.getItem('negociofacil.data.v1')")

    b.close()

print('OK: interface gratuita, login ADM, planos Free/Pro/Empresarial, bloqueio, cadastros, backup e XSS.')
